# TFG-OutlierDetection
Implementación de algoritmos para detección de anomalías, basados en proximidad
